package com.example.abarajithan.a49erapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class PowerGenerator extends AppCompatActivity {

    String res,templight1,templight2, light1,light2,tempfan,fan;
    String print ="OVER USE-AGE";
    public int powerValue = 0;
    String[] tempfloor1light,tempfloor2light;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.powergeneratedlayout);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_FLOOR1_UTILITY_LED, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                   // Toast.makeText(getApplicationContext(),jsonObject.getString("floor1"),Toast.LENGTH_LONG).show();
                   // Toast.makeText(getApplicationContext(),jsonObject.getString("floor2"),Toast.LENGTH_LONG).show();
//                    JSONObject resp = (JSONObject)jsonObject.get("message");
                    JSONObject resp1 = (JSONObject)jsonObject.get("floor1");
                    JSONObject resp2 = (JSONObject)jsonObject.get("floor2");
                    JSONObject resp3 = (JSONObject)jsonObject.get("thermo");

                    String floor1_light1 = "", floor1_light2 = "", floor2_light1 = "", floor2_light2="", tempfan = "", fan="";
                    floor1_light1 = resp1.getString("light1");
                    floor1_light2 = resp1.getString("light2");

                    floor2_light1 = resp2.getString("light1");
                    floor2_light2 = resp2.getString("light2");


//                    tempfan = resp2.getString("light1");
                    fan = resp3.getString("fan");

                    System.out.println("light1: "+floor1_light1+"  light2: "+floor1_light2);

                    if (floor1_light1.equalsIgnoreCase("1"))
                        powerValue = powerValue +  10;
                    if (floor1_light2.equalsIgnoreCase("1"))
                        powerValue = powerValue +  10;
                    if (floor2_light1.equalsIgnoreCase("1"))
                        powerValue = powerValue +  10;
                    if (floor2_light2.equalsIgnoreCase("1"))
                        powerValue = powerValue +  10;

                    if (fan.equalsIgnoreCase("1"))
                        powerValue = powerValue +  20;

                    if(powerValue >= 40)
                    {
                        Toast.makeText(getApplicationContext(), "WARNING...: OVER-USAGE of POWER",
                                Toast.LENGTH_LONG).show();

//                        Toast.makeText(getApplicationContext(),jsonObject.getString("floor1"),Toast.LENGTH_LONG).show();
                         //Toast.makeText(getApplicationContext(),jsonObject.getString("floor2"),Toast.LENGTH_LONG).show();

                    }


                    TextView textView = (TextView) findViewById(R.id.textView_Powervalue);
                    textView.setText(Integer.toString(powerValue));

                } catch (JSONException e) {
                    e.printStackTrace();

                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // progressDialog.hide();
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                return params;
            }
        };
        RequestHandler.getInstance(this).addToRequestQueue(stringRequest);

    }
}
